@echo off
chcp 65001 >nul
title [War of Genesis] LiveSync 1-Click Launcher
color 0B
cls

echo.
echo  ================================================================
echo    WAR OF GENESIS IDLE LOOT -- LIVESYNC 1-CLICK LAUNCHER
echo    (Tu dong cai Node.js, nap Hook, mo Game va ket noi Web)
echo  ================================================================
echo.

:: ================================================================
:: 1. KIEM TRA VA TU DONG TAI/CAI DAT NODE.JS NEU CHUA CO
:: ================================================================
where node >nul 2>&1
if not errorlevel 1 goto NODE_READY

if exist "%ProgramFiles%\nodejs\node.exe" (
    set "PATH=%ProgramFiles%\nodejs;%PATH%"
    goto NODE_READY
)
if exist "%ProgramFiles(x86)%\nodejs\node.exe" (
    set "PATH=%ProgramFiles(x86)%\nodejs;%PATH%"
    goto NODE_READY
)
if exist "%LocalAppData%\Programs\node\node.exe" (
    set "PATH=%LocalAppData%\Programs\node;%PATH%"
    goto NODE_READY
)

echo  ----------------------------------------------------------------
echo   [!] May tinh cua ban chua cai dat Node.js.
echo   [!] Dang tu dong tai va cai dat Node.js (ban LTS chinh thuc)...
echo  ----------------------------------------------------------------
echo.

:: Thu cai dat qua winget (Windows Package Manager tren Win 10/11)
where winget >nul 2>&1
if not errorlevel 1 (
    echo  [*] Dang cai dat Node.js qua Windows Package Manager...
    winget install OpenJS.NodeJS.LTS --silent --accept-source-agreements --accept-package-agreements >nul 2>&1
    if exist "%ProgramFiles%\nodejs\node.exe" (
        set "PATH=%ProgramFiles%\nodejs;%PATH%"
        goto NODE_READY
    )
)

:: Neu winget khong thanh cong, tai truc tiep file MSI tu nodejs.org
echo  [*] Dang tai file cai dat Node.js tu nodejs.org (khoang 30MB)...
set "NODE_MSI=%TEMP%\nodejs_installer.msi"
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; $wc = New-Object System.Net.WebClient; $wc.DownloadFile('https://nodejs.org/dist/v20.18.0/node-v20.18.0-x64.msi', '%NODE_MSI%')"

if exist "%NODE_MSI%" (
    echo  [*] Dang tien hanh cai dat Node.js vao he thong...
    msiexec.exe /i "%NODE_MSI%" /passive /norestart
    del /f /q "%NODE_MSI%" >nul 2>&1
)

:: Cap nhat lai bien moi truong PATH sau khi cai dat
if exist "%ProgramFiles%\nodejs\node.exe" (
    set "PATH=%ProgramFiles%\nodejs;%PATH%"
    goto NODE_READY
)
if exist "%ProgramFiles(x86)%\nodejs\node.exe" (
    set "PATH=%ProgramFiles(x86)%\nodejs;%PATH%"
    goto NODE_READY
)

where node >nul 2>&1
if errorlevel 1 (
    color 0C
    echo.
    echo  [LOI] Chua the cai dat Node.js tu dong.
    echo  Vui long vao trang chu https://nodejs.org de tai ban LTS va cai thu cong.
    echo.
    pause
    exit /b 1
)

:NODE_READY
echo  [OK] Node.js da san sang:
node -v
echo.

:: ================================================================
:: 2. KIEM TRA DU LIEU GAME TRONG APPDATA
:: ================================================================
set "APPDATA_TARGET=%USERPROFILE%\AppData\LocalLow\Newnormal Soft\War of Genesis Idle Loot\scripts\src"
set "INIT_FILE=%APPDATA_TARGET%\init.bundle.mjs"

if exist "%INIT_FILE%" goto GAME_DATA_READY

color 0C
echo  [LOI] Khong tim thay du lieu game tai:
echo  "%APPDATA_TARGET%"
echo.
echo  Hay chac chan ban da tai va mo game it nhat 1 lan truoc khi cai dat.
echo.
pause
exit /b 1

:GAME_DATA_READY

:: ================================================================
:: 3. CHUYEN VE THU MUC CHUA FILE BAT VA KIEM TRA CAC FILE HO TRO
:: ================================================================
cd /d "%~dp0"

if not exist "%~dp0install_game_hook_v2.js" (
    color 0C
    echo  [LOI] Khong tim thay file install_game_hook_v2.js trong thu muc nay!
    echo.
    echo  Vui long tai file LiveSync_1Click.zip va giai nen DAY DU ca 3 file vao thu muc game:
    echo    1. cai_dat_livesync.bat
    echo    2. install_game_hook_v2.js
    echo    3. livesync_bridge.js
    echo.
    pause
    exit /b 1
)

if not exist "%~dp0livesync_bridge.js" (
    color 0C
    echo  [LOI] Khong tim thay file livesync_bridge.js trong thu muc nay!
    echo.
    echo  Vui long tai file LiveSync_1Click.zip va giai nen DAY DU ca 3 file vao thu muc game.
    echo.
    pause
    exit /b 1
)

:: ================================================================
:: 4. CAI DAT REAL-TIME HOOK VAO GAME
:: ================================================================
echo  [1/4] Dang cai dat Real-Time Hook vao game...
node "%~dp0install_game_hook_v2.js"
if errorlevel 1 (
    color 0C
    echo  [LOI] Khong the cai dat Hook vao game!
    pause
    exit /b 1
)

:: ================================================================
:: 5. TAT TIEN TRINH BRIDGE CU TRONG PORT 10998
:: ================================================================
for /f "tokens=5" %%a in ('netstat -ano 2^>nul ^| findstr ":10998 "') do (
    taskkill /PID %%a /F >nul 2>&1
)
ping -n 2 127.0.0.1 >nul

:: ================================================================
:: 6. KHOI DONG GAME QUA STEAM (NEU CHUA CHAY)
:: ================================================================
echo.
echo  [2/4] Dang kiem tra va khoi dong game War of Genesis...
tasklist | findstr /I "Genesis.exe" >nul 2>&1
if errorlevel 1 (
    echo        Dang kich hoat mo game qua Steam...
    start steam://run/4891320
    echo        [OK] Da gui tin hieu mo game qua Steam!
) else (
    echo        [OK] Game Genesis.exe dang chay san!
)

:: ================================================================
:: 7. MO WEB HELPER TREN TRINH DUYET MAC DINH
:: ================================================================
echo.
echo  [3/4] Dang mo Web Helper tren trinh duyet...
ping -n 3 127.0.0.1 >nul
start "" "https://war-of-genesis-helper.web.app"

:: ================================================================
:: 8. KHOI DONG LIVESYNC BRIDGE TREN CONG 10998
:: ================================================================
echo.
echo  [4/4] Dang khoi dong LiveSync Bridge tren cong 10998...
echo  ================================================================
echo   [OK] Game da duoc bat va Web Helper da mo tren trinh duyet!
echo   [OK] LiveSync Bridge dang ket noi tren ws://127.0.0.1:10998!
echo   [Luu y] Hay giu cua so nay mo trong khi choi game va dung web.
echo  ================================================================
echo.

node "%~dp0livesync_bridge.js"

echo.
echo  [KET THUC] Bridge da dung.
pause
