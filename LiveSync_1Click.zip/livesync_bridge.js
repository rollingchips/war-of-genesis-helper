/**
 * War of Genesis Idle Loot — LiveSync Bridge v3.1
 * Đọc user_save_profile_enriched.json và expose qua WebSocket ws://127.0.0.1:10998
 * Hỗ trợ hàng đợi lệnh (Sequential Command Queue) & thực thi Lò Rèn / Kho Ngọc in-game.
 *
 * Cách dùng: node livesync_bridge.js
 * Yêu cầu: Node.js 16+ (không cần cài thêm package)
 */

const http  = require('http');
const net   = require('net');
const fs    = require('fs');
const path  = require('path');
const crypto = require('crypto');

const PORT = 10998;
const GAME_DIR = __dirname;
const PROFILE_FILE  = path.join(GAME_DIR, 'user_save_profile.json');
const ENRICHED_FILE = path.join(GAME_DIR, 'user_save_profile_enriched.json');
const PENDING_FILE  = path.join(GAME_DIR, 'pending_eval.json');
const RESULT_FILE   = path.join(GAME_DIR, 'eval_result.json');
const POLL_INTERVAL_MS = 2000; // push update mỗi 2 giây

// ── Màu ANSI ────────────────────────────────────────────────────────────────
const C = { reset:'\x1b[0m', green:'\x1b[32m', yellow:'\x1b[33m', cyan:'\x1b[36m', red:'\x1b[31m', gray:'\x1b[90m' };
const log = (msg, color=C.cyan) => console.log(`${color}[Bridge]${C.reset} ${msg}`);

// ── Đọc profile từ disk ──────────────────────────────────────────────────────
function readProfile() {
  try {
    const file = fs.existsSync(ENRICHED_FILE) ? ENRICHED_FILE : PROFILE_FILE;
    const raw  = fs.readFileSync(file, 'utf8');
    const data = JSON.parse(raw);
    data.isLiveConnected  = true;
    data.liveSyncSource   = 'game_hook_v3';
    data.exportedAt       = data.exportedAt || Date.now();
    return data;
  } catch (e) {
    return null;
  }
}

// ── WebSocket handshake (RFC 6455) ───────────────────────────────────────────
function wsHandshake(req, socket) {
  const key = req.headers['sec-websocket-key'];
  if (!key) { socket.destroy(); return false; }
  const accept = crypto
    .createHash('sha1')
    .update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11')
    .digest('base64');
  socket.write(
    'HTTP/1.1 101 Switching Protocols\r\n' +
    'Upgrade: websocket\r\n' +
    'Connection: Upgrade\r\n' +
    `Sec-WebSocket-Accept: ${accept}\r\n\r\n`
  );
  return true;
}

// ── Encode WebSocket text frame (RFC 6455) ────────────────────────────────────
function wsSend(socket, text) {
  if (!socket || socket.destroyed) return;
  const payload = Buffer.from(text, 'utf8');
  const len     = payload.length;
  let header;
  if (len < 126) {
    header = Buffer.from([0x81, len]);
  } else if (len < 65536) {
    header = Buffer.alloc(4);
    header[0] = 0x81; header[1] = 126;
    header.writeUInt16BE(len, 2);
  } else {
    header = Buffer.alloc(10);
    header[0] = 0x81; header[1] = 127;
    header.writeBigUInt64BE(BigInt(len), 2);
  }
  try { socket.write(Buffer.concat([header, payload])); } catch(_) {}
}

// ── Decode incoming WS frame ────────────────────────────────────────────────
function wsDecode(buf) {
  if (buf.length < 2) return null;
  const masked = (buf[1] & 0x80) !== 0;
  let payloadLen = buf[1] & 0x7f;
  let offset = 2;
  if (payloadLen === 126) {
    if (buf.length < 4) return null;
    payloadLen = buf.readUInt16BE(2);
    offset = 4;
  } else if (payloadLen === 127) {
    if (buf.length < 10) return null;
    payloadLen = Number(buf.readBigUInt64BE(2));
    offset = 10;
  }
  const minLen = offset + (masked ? 4 : 0) + payloadLen;
  if (buf.length < minLen) return null;

  if (!masked) return buf.slice(offset, offset + payloadLen).toString('utf8');
  const mask = buf.slice(offset, offset + 4);
  offset += 4;
  const data = Buffer.alloc(payloadLen);
  for (let i = 0; i < payloadLen; i++) data[i] = buf[offset + i] ^ mask[i % 4];
  return data.toString('utf8');
}

// ── CDP-compatible response ─────────────────────────────────────────────────
function buildCdpResponse(id, profileData) {
  const valueJson = (typeof profileData === 'string') ? profileData : JSON.stringify(profileData);
  return JSON.stringify({
    id: id || 1,
    result: {
      result: {
        type: 'string',
        value: valueJson
      }
    }
  });
}

// ── Danh sách clients kết nối ─────────────────────────────────────────────────
const clients = new Set();
let lastProfileJson = '';

function pushUpdate(profileData) {
  const json = JSON.stringify(profileData);
  if (json === lastProfileJson) return;
  lastProfileJson = json;
  const msg = buildCdpResponse(1, profileData);
  let count = 0;
  for (const socket of clients) {
    wsSend(socket, msg);
    count++;
  }
}

// ── Sequential In-Game Command Queue (Tránh ghi đè file IPC) ──────────────────
const evalQueue = [];
let isQueueBusy = false;

function enqueueEvalCommand(reqId, code, socket) {
  evalQueue.push({ id: reqId, code: code, socket: socket });
  processNextInQueue();
}

function processNextInQueue() {
  if (isQueueBusy || evalQueue.length === 0) return;
  isQueueBusy = true;

  const item = evalQueue.shift();
  const reqId = item.id;
  const code = item.code;
  const socket = item.socket;

  try {
    if (fs.existsSync(RESULT_FILE)) {
      try { fs.unlinkSync(RESULT_FILE); } catch(_) {}
    }
    fs.writeFileSync(PENDING_FILE, JSON.stringify({ id: reqId, code: code }), 'utf8');

    let waited = 0;
    const pollInterval = setInterval(() => {
      waited += 20;
      if (fs.existsSync(RESULT_FILE)) {
        clearInterval(pollInterval);
        try {
          const resData = JSON.parse(fs.readFileSync(RESULT_FILE, 'utf8'));
          try { fs.unlinkSync(RESULT_FILE); } catch(_) {}
          if (resData.result) {
            log(`⚡ [In-Game Action] Thực thi thành công (id=${reqId}) sau ${waited}ms!`, C.green);
            wsSend(socket, buildCdpResponse(reqId, resData.result));
            isQueueBusy = false;
            setImmediate(processNextInQueue);
            return;
          }
        } catch(_) {}
        // Fallback
        const prof = readProfile();
        if (prof) wsSend(socket, buildCdpResponse(reqId, prof));
        isQueueBusy = false;
        setImmediate(processNextInQueue);
      } else if (waited >= 2000) {
        clearInterval(pollInterval);
        try { if (fs.existsSync(PENDING_FILE)) fs.unlinkSync(PENDING_FILE); } catch(_) {}
        const prof = readProfile();
        if (prof) wsSend(socket, buildCdpResponse(reqId, prof));
        isQueueBusy = false;
        setImmediate(processNextInQueue);
      }
    }, 20);
  } catch(e) {
    isQueueBusy = false;
    setImmediate(processNextInQueue);
  }
}

// ── HTTP Server ──────────────────────────────────────────────────────────────
const server = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');

  if (req.url === '/json' || req.url === '/json/version') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      Browser: 'Genesis/LiveSync-Bridge/3.1',
      'Protocol-Version': '1.3',
      webSocketDebuggerUrl: `ws://127.0.0.1:${PORT}`
    }));
    return;
  }

  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end('LiveSync Bridge v3.1 — War of Genesis Idle Loot\n');
});

server.on('upgrade', (req, socket, head) => {
  if (!wsHandshake(req, socket)) return;

  log(`Client kết nối: ${socket.remoteAddress}`, C.green);
  clients.add(socket);

  let buf = Buffer.alloc(0);

  socket.on('data', chunk => {
    buf = Buffer.concat([buf, chunk]);
    try {
      const text = wsDecode(buf);
      if (!text) return;
      buf = Buffer.alloc(0);

      let req_id = 1;
      let evalCode = '';
      try {
        const parsed = JSON.parse(text);
        req_id = parsed.id || 1;
        if (parsed.params && parsed.params.expression) {
          evalCode = parsed.params.expression;
        }
      } catch(_) {
        evalCode = text;
      }

      // Check if this is an interactive action command (Lò rèn / Kho ngọc / In-game)
      const isActionCmd = evalCode && (
        evalCode.includes('__runJewelAction') && !evalCode.includes('NetContainerUser')
      );

      if (isActionCmd) {
        // Enqueue into in-game execution queue
        log(`📥 [Action Enqueued] id=${req_id}`, C.cyan);
        enqueueEvalCommand(req_id, evalCode, socket);
      } else {
        // Normal profile poll -> Instant response from memory/file without game IPC overhead!
        const profile = readProfile();
        if (profile) {
          wsSend(socket, buildCdpResponse(req_id, profile));
        }
      }
    } catch(decodeErr) {
      buf = Buffer.alloc(0);
    }
  });

  socket.on('close', () => { clients.delete(socket); });
  socket.on('error', () => { clients.delete(socket); });
});

// ── Polling & File Watcher ──────────────────────────────────────────────────
setInterval(() => {
  if (clients.size === 0) return;
  const profile = readProfile();
  if (profile) pushUpdate(profile);
}, POLL_INTERVAL_MS);

function watchFiles() {
  const watchFile = fs.existsSync(ENRICHED_FILE) ? ENRICHED_FILE : PROFILE_FILE;
  try {
    fs.watch(watchFile, { persistent: false }, (event) => {
      if (event === 'change') {
        setTimeout(() => {
          const profile = readProfile();
          if (profile) pushUpdate(profile);
        }, 100);
      }
    });
  } catch(_) {}
}

// ── Khởi động ─────────────────────────────────────────────────────────────────
server.listen(PORT, '127.0.0.1', () => {
  console.log('');
  console.log(`${C.green}╔══════════════════════════════════════════════════════╗${C.reset}`);
  console.log(`${C.green}║   War of Genesis — LiveSync Bridge v3.1  ✅ ONLINE   ║${C.reset}`);
  console.log(`${C.green}╚══════════════════════════════════════════════════════╝${C.reset}`);
  console.log(`${C.cyan}  WebSocket : ws://127.0.0.1:${PORT}${C.reset}`);
  console.log(`${C.cyan}  Đọc từ   : ${fs.existsSync(ENRICHED_FILE) ? 'user_save_profile_enriched.json' : 'user_save_profile.json'}${C.reset}`);
  console.log(`${C.cyan}  Tính năng : Tự động Ghép Ngọc (Lò Rèn) & Cất Ngọc (Kho) ${C.reset}`);
  console.log('');

  const profile = readProfile();
  if (profile) {
    log(`✅ Profile tìm thấy: ${profile.nickname} Lv.${profile.level} (CP: ${profile.combatPower})`, C.green);
    watchFiles();
  }
});

let retriedPort = false;
server.on('error', (err) => {
  if (err.code === 'EADDRINUSE' && !retriedPort) {
    retriedPort = true;
    log(`⚠️ Port ${PORT} đang bận, đang tự động giải phóng tiến trình cũ...`, C.yellow);
    try {
      const { execSync } = require('child_process');
      const out = execSync(`netstat -ano | findstr :${PORT} | findstr LISTENING`, { encoding: 'utf8' });
      const match = out.trim().split(/\s+/).pop();
      if (match && Number(match) > 0 && Number(match) !== process.pid) {
        execSync(`taskkill /PID ${match} /F`);
        log(`✅ Đã giải phóng port ${PORT} thành công!`, C.green);
      }
      setTimeout(() => {
        server.listen(PORT, '127.0.0.1');
      }, 600);
      return;
    } catch(e) {
      log(`❌ Không thể tự giải phóng port: ${e.message}`, C.red);
    }
  } else {
    log(`❌ Lỗi server: ${err.message}`, C.red);
  }
  process.exit(1);
});

process.on('uncaughtException', (err) => {
  try { console.log('[Bridge Error Caught]', err.message); } catch(_) {}
});
process.on('unhandledRejection', (reason) => {
  try { console.log('[Bridge Rejection Caught]', reason); } catch(_) {}
});
