const fs = require('fs');
const path = require('path');

const initPath = path.join(
  process.env.USERPROFILE,
  'AppData/LocalLow/Newnormal Soft/War of Genesis Idle Loot/scripts/src/init.bundle.mjs'
);

if (!fs.existsSync(initPath)) {
  console.error('File not found:', initPath);
  process.exit(1);
}

let code = fs.readFileSync(initPath, 'utf8');

// Strip previous hook if present
if (code.includes('LIVESYNC REALTIME IN-GAME HOOK')) {
  const idx = code.indexOf('// === LIVESYNC REALTIME IN-GAME HOOK ===');
  code = code.substring(0, idx);
}

const hook = `
// === LIVESYNC REALTIME IN-GAME HOOK ===
;(()=>{
  try {
    if (typeof CS !== 'undefined' && CS.UnityEngine && CS.UnityEngine.Debug) {
      CS.UnityEngine.Debug.Log("[LiveSync Hook v3.2] Full Jewel Forge, Storage & T3 Fusion Engine READY!");
    }
  } catch(e) {}

  let lastDump = 0;
  let isEvaluating = false;
  let jewelFusedHistory = [];

  // Helper to dump enriched profile to disk instantly
  function dumpEnrichedProfile() {
    try {
      if (typeof nn === 'undefined' || !nn || !nn.netData || !nn.netData._mapContainer) return;
      if (typeof CS === 'undefined' || !CS.UnityEngine || !CS.UnityEngine.Application || !CS.NTSHelper) return;

      const dataPath = CS.UnityEngine.Application.dataPath;
      if (!dataPath) return;
      const targetFile = dataPath + '/../user_save_profile_enriched.json';

      let userC, stageC, treeC, presetC, itemC, dungC;
      for (let [k, v] of nn.netData._mapContainer.entries()) {
        const name = k.name || k.toString();
        if (name === 'NetContainerUser') userC = v;
        if (name === 'NetContainerStage') stageC = v;
        if (name === 'NetContainerTree') treeC = v;
        if (name === 'NetContainerPreset') presetC = v;
        if (name === 'NetContainerItem') itemC = v;
        if (name === 'NetContainerDungeonInfo') dungC = v;
      }

      const currencies = {};
      if (itemC && itemC._mapItemStack) {
        for (let k of itemC._mapItemStack.keys()) {
          const it = itemC._mapItemStack.getValue(k);
          if (it) currencies[k] = { tid: it._itemTid, count: it._cnt ? it._cnt.toString() : '0' };
        }
      }

      // Extract all jewels for Lò Rèn & Kho Ngọc
      const jewels = [];
      let totalStorage = 42;
      let usedStorage = 0;

      // Count Tier 3 Gear & Accessories across Bag (1) and Storage (2)
      let t3GearInv = 0;
      let t3GearStorage = 0;
      let t3AccInv = 0;
      let t3AccStorage = 0;
      const t3GearByLevel = {};
      const t3AccByLevel = {};

      try {
        if (nn.net && nn.net.data && nn.net.data.item) {
          const allItems = nn.net.data.item.getAllItemNotStack();
          usedStorage = allItems.filter(i => i.location === 2).length;
          
          let storagePlus = 0;
          try {
            if (nn.services && nn.services.contentState) {
              storagePlus = Number(nn.services.contentState.getValue(1107) || 0);
            }
          } catch(e) {}
          totalStorage = (1 + storagePlus) * 42;

          for (let it of allItems) {
            // Jewel check
            const dbInfo = nn.db.item ? nn.db.item.get(it.itemTid) : null;
            if (dbInfo && dbInfo.ItemType === 6) { // 6 = Jewel (Ngọc)
              const loc = nn.db.locale ? nn.db.locale.get(dbInfo.ItemName) : null;
              jewels.push({
                itemId: it.itemId ? it.itemId.toString() : '',
                itemTid: it.itemTid,
                name: loc?.VI || loc?.EN || dbInfo.ItemName,
                rating: dbInfo.RatingType,
                icon: dbInfo.Icon || dbInfo.ItemIcon || '',
                location: it.location, // 1: Balo, 2: Kho, 3: Khảm
                slot: it.slotIdx,
                isLock: !!(it.isLock || it._isLock)
              });
            }

            // Tier 3 Gear & Acc check (Balo 1 & Kho 2)
            if (!it.isLock && !it._isLock && (it.location === 1 || it.location === 2)) {
              const dbEq = nn.db.equip ? nn.db.equip.get(it.itemTid) : null;
              if (dbEq && dbEq.RatingType === 3) {
                const isGear = dbEq.EquipType === 1 || (dbEq.PartsType && dbEq.PartsType <= 8);
                const isAcc = dbEq.EquipType === 2 || (dbEq.PartsType && dbEq.PartsType >= 9);
                let itemLv = (dbEq && dbEq.LimitLevel) || 1;
                try {
                  const ws = nn.services && nn.services.workshop;
                  const info = ws ? ws.getTableInfo(it.itemTid, it.itemId) : null;
                  if (info && info.baseLimitLevel > 0) itemLv = info.baseLimitLevel;
                } catch(e) {}

                if (isGear) {
                  if (it.location === 1) t3GearInv++;
                  else if (it.location === 2) t3GearStorage++;
                  t3GearByLevel[itemLv] = (t3GearByLevel[itemLv] || 0) + 1;
                } else if (isAcc) {
                  if (it.location === 1) t3AccInv++;
                  else if (it.location === 2) t3AccStorage++;
                  t3AccByLevel[itemLv] = (t3AccByLevel[itemLv] || 0) + 1;
                }
              }
            }
          }
        }
      } catch(je) {}

      const t3GearCount = t3GearInv + t3GearStorage;
      const t3AccCount = t3AccInv + t3AccStorage;
      const t3GearMaxSameLevel = Math.max(0, ...Object.values(t3GearByLevel));
      const t3GearReadySameLevel = Object.values(t3GearByLevel).reduce((acc, cnt) => acc + Math.floor(cnt / 6), 0);
      const t3AccMaxSameLevel = Math.max(0, ...Object.values(t3AccByLevel));
      const t3AccReadySameLevel = Object.values(t3AccByLevel).reduce((acc, cnt) => acc + Math.floor(cnt / 3), 0);

      const jewelsData = {
        jewels: jewels,
        storageUsed: usedStorage,
        storageTotal: totalStorage,
        includeStorage: true,
        fusedHistory: jewelFusedHistory.splice(0, jewelFusedHistory.length),
        depositedCount: 0,
        withdrawnCount: 0,
        t3GearCount: t3GearCount,
        t3GearInvCount: t3GearInv,
        t3GearStorageCount: t3GearStorage,
        t3GearMaxSameLevel: t3GearMaxSameLevel,
        t3GearReadySameLevel: t3GearReadySameLevel,
        t3AccCount: t3AccCount,
        t3AccInvCount: t3AccInv,
        t3AccStorageCount: t3AccStorage,
        t3AccMaxSameLevel: t3AccMaxSameLevel,
        t3AccReadySameLevel: t3AccReadySameLevel
      };

      const equippedGear = [];
      if (nn.net && nn.net.data && nn.net.data.preset) {
        const prSvc = nn.services && nn.services.preset;
        const currentPrimaryNo = prSvc ? (prSvc.currentPrimaryNo || 1) : 1;
        const p3 = nn.net.data.preset.getPresetNoData(3, currentPrimaryNo) || nn.net.data.preset.getPresetNoData(3, 1);
        if (p3 && p3._map) {
          p3._map.forEach((val, k) => {
            if (val && val._info && val._info._itemTid) {
              equippedGear.push({
                id: val._info._itemId ? val._info._itemId.toString() : '',
                tid: val._info._itemTid,
                location: 1,
                slot: Number(k),
                parts_type: Number(k),
                equip_type: 1,
                options: val._info._randomOptions || []
              });
            }
          });
        }
        const p4 = nn.net.data.preset.getPresetNoData(4, currentPrimaryNo) || nn.net.data.preset.getPresetNoData(4, 1);
        if (p4 && p4._map) {
          p4._map.forEach((val, k) => {
            if (val && val._info && val._info._itemTid) {
              equippedGear.push({
                id: val._info._itemId ? val._info._itemId.toString() : '',
                tid: val._info._itemTid,
                location: 1,
                slot: Number(k),
                parts_type: Number(k),
                equip_type: 2,
                options: val._info._randomOptions || []
              });
            }
          });
        }
      }

      const trainingSkills = {};
      const skillTreeAllocations = {};
      if (treeC && treeC._mapTreeInfo) {
        const cat1 = treeC._mapTreeInfo.get(1);
        if (cat1 && cat1.keys) {
          for (let sk of cat1.keys()) {
            const node = cat1.getValue(sk);
            if (node) trainingSkills[sk] = { tid: node._treeTid, level: (node._treeTid % 100) };
          }
        }
        const cat4 = treeC._mapTreeInfo.get(4);
        if (cat4 && cat4.keys) {
          for (let sk of cat4.keys()) {
            const node = cat4.getValue(sk);
            if (node) skillTreeAllocations[sk] = { tid: node._treeTid, level: (node._treeTid % 100) };
          }
        }
      }

      let altarLevel = 28;
      if (treeC && treeC._mapTreeInfo) {
        const cat3 = treeC._mapTreeInfo.get(3);
        if (cat3 && cat3.keys) {
          for (let k of cat3.keys()) {
            const node = cat3.getValue(k);
            if (node && node._treeTid) altarLevel = (node._treeTid % 100);
          }
        }
      }

      const heroSvc = nn.services && nn.services.hero;
      const liveHeroTid = (heroSvc && heroSvc.getCurrentHeroTid) ? heroSvc.getCurrentHeroTid() : 204;
      const liveClassType = (heroSvc && heroSvc.getCurrentHeroClassType) ? heroSvc.getCurrentHeroClassType() : 2;
      let heroClass = 'Ranged';
      if (liveClassType === 3 || liveHeroTid >= 300) heroClass = 'Mage';
      else if (liveClassType === 2 || (liveHeroTid >= 200 && liveHeroTid < 300)) heroClass = 'Ranged';
      else if (liveClassType === 1 || liveHeroTid < 200) heroClass = 'Melee';

      const systemsData = {
        pet: { tid: 610010, level: 3, name: 'Mèo Con' },
        wing: { tid: 420050, level: 6, name: 'Expedition Wings' },
        rune: { tid: 520030, level: 5, name: "Explorer's Rune" },
        machina: { tid: null, level: 0, unlocked: false },
        altar: { level: altarLevel }
      };

      let liveRaidDamage = 0;
      let liveWorldBossDamage = 0;
      if (dungC) {
        try {
          const d3 = dungC.getDungeonInfo(3);
          if (d3 && d3._dungeonRecords) {
            const rec1 = d3._dungeonRecords.find(function(r) { return r._type === 1 || r.type === 1; });
            if (rec1 && rec1._value) liveRaidDamage = Number(rec1._value) || 0;
          }
          const d2 = dungC.getDungeonInfo(2);
          if (d2 && d2._dungeonRecords) {
            const rec1 = d2._dungeonRecords.find(function(r) { return r._type === 1 || r.type === 1; });
            if (rec1 && rec1._value) liveWorldBossDamage = Number(rec1._value) || 0;
          }
        } catch(e) {}
      }

      const payload = {
        nickname: userC && userC._user ? userC._user._nick : 'Lee',
        level: userC && userC._user ? userC._user._lv : 46,
        combatPower: userC && userC._profile ? userC._profile._combatPower : '76811',
        stageTid: stageC && stageC._stageInfo ? stageC._stageInfo._stageTid : 14306,
        maxUnlockedStageTid: stageC && stageC._stageInfo ? stageC._stageInfo._stageTid : 14306,
        heroTid: liveHeroTid,
        heroClass: heroClass,
        currentPrimaryNo: 1,
        raidDamage: liveRaidDamage,
        worldBossDamage: liveWorldBossDamage,
        specialBattles: {
          raidDamage: liveRaidDamage,
          worldBossDamage: liveWorldBossDamage
        },
        currencies: currencies,
        jewelsData: jewelsData,
        equippedGear: equippedGear,
        trainingSkills: trainingSkills,
        skillTreeAllocations: skillTreeAllocations,
        systemsData: systemsData,
        altarLevel: altarLevel,
        isLiveConnected: true,
        liveSyncSource: 'game_hook_v3',
        exportedAt: new Date().toISOString()
      };

      CS.NTSHelper.WriteAllText(targetFile, JSON.stringify(payload, null, 2));
    } catch(err) {}
  }

  // ── IN-GAME JEWEL & STORAGE ACTION HANDLER ────────────────────────────────
  globalThis.__runJewelAction = async function(cmd) {
    if (!cmd || !cmd.action) return JSON.stringify({ error: 'No action specified' });
    try {
      if (cmd.action === 'deposit') {
        const gs = nn.net.manager.gameSession;
        const allItems = nn.net.data.item.getAllItemNotStack();
        const toDeposit = [];
        for (let it of allItems) {
          if (it.location === 1 && !it.isLock && !it._isLock) {
            const dbInfo = nn.db.item.get(it.itemTid);
            if (dbInfo && dbInfo.ItemType === 6) { // 6 = Jewel
              toDeposit.push(it.itemId);
            }
          }
        }
        if (toDeposit.length > 0) {
          let storagePlus = 0;
          try {
            if (nn.services && nn.services.contentState) {
              storagePlus = Number(nn.services.contentState.getValue(1107) || 0);
            }
          } catch(e) {}
          const totalStorage = (1 + storagePlus) * 42;
          const usedStorage = allItems.filter(i => i.location === 2).length;
          const avail = Math.max(0, totalStorage - usedStorage);
          const chunk = toDeposit.slice(0, avail);
          if (chunk.length > 0) {
            const res = await gs.reqStorageMoveInList(chunk);
            dumpEnrichedProfile();
            return JSON.stringify({ success: true, action: 'deposit', count: chunk.length, res: res ? (res.NetResult || 0) : 0 });
          } else {
            return JSON.stringify({ success: false, action: 'deposit', count: 0, reason: 'Kho đồ đã đầy!' });
          }
        }
        return JSON.stringify({ success: true, action: 'deposit', count: 0, msg: 'No bag jewels to deposit' });
      }

      if (cmd.action === 'withdraw') {
        const gs = nn.net.manager.gameSession;
        const allItems = nn.net.data.item.getAllItemNotStack();
        const toWithdraw = [];
        for (let it of allItems) {
          if (it.location === 2 && !it.isLock && !it._isLock) {
            const dbInfo = nn.db.item.get(it.itemTid);
            if (dbInfo && dbInfo.ItemType === 6) {
              toWithdraw.push(it.itemId);
            }
          }
        }
        if (toWithdraw.length > 0) {
          const res = await gs.reqStorageMoveOutList(toWithdraw);
          dumpEnrichedProfile();
          return JSON.stringify({ success: true, action: 'withdraw', count: toWithdraw.length, res: res ? (res.NetResult || 0) : 0 });
        }
        return JSON.stringify({ success: true, action: 'withdraw', count: 0, msg: 'No vault jewels to withdraw' });
      }

      if (cmd.action === 'depositType') {
        const gs = nn.net.manager.gameSession;
        const allItems = nn.net.data.item.getAllItemNotStack();
        const toDeposit = [];
        for (let it of allItems) {
          if (it.location === 1 && !it.isLock && !it._isLock && it.itemTid === cmd.itemTid) {
            toDeposit.push(it.itemId);
          }
        }
        if (toDeposit.length > 0) {
          const res = await gs.reqStorageMoveInList(toDeposit);
          dumpEnrichedProfile();
          return JSON.stringify({ success: true, action: 'depositType', count: toDeposit.length });
        }
        return JSON.stringify({ success: true, action: 'depositType', count: 0 });
      }

      if (cmd.action === 'withdrawType') {
        const gs = nn.net.manager.gameSession;
        const allItems = nn.net.data.item.getAllItemNotStack();
        const toWithdraw = [];
        for (let it of allItems) {
          if (it.location === 2 && !it.isLock && !it._isLock && it.itemTid === cmd.itemTid) {
            toWithdraw.push(it.itemId);
          }
        }
        if (toWithdraw.length > 0) {
          const res = await gs.reqStorageMoveOutList(toWithdraw);
          dumpEnrichedProfile();
          return JSON.stringify({ success: true, action: 'withdrawType', count: toWithdraw.length });
        }
        return JSON.stringify({ success: true, action: 'withdrawType', count: 0 });
      }

      if (cmd.action === 'fuse') {
        const ws = nn.services.workshop;
        if (!ws) return JSON.stringify({ error: 'Workshop service not found' });
        ws.setFusionContentType(20); // 20 = Jewel
        ws.setAutoRegisterIncludeStorage('Fusion', cmd.includeStorage !== false);
        let targetTiers = [];
        if (cmd.tier) {
          targetTiers = [Number(cmd.tier)];
        } else if (Array.isArray(cmd.allowedTiers) && cmd.allowedTiers.length > 0) {
          targetTiers = cmd.allowedTiers.map(Number).filter(t => t >= 1 && t <= 6);
        }
        if (targetTiers.length === 0) {
          return JSON.stringify({ success: false, action: 'fuse', fusedCount: 0, reason: 'No allowed tiers configured' });
        }
        const fusedResults = [];

        for (let t of targetTiers) {
          ws.setAutoRegisterRating('Fusion', t);
          let loopGuard = 0;
          while (loopGuard < 20) {
            const regCnt = ws.autoRegisterFusion();
            const isFull = ws.isFusionStagingFull ? ws.isFusionStagingFull() : false;
            if (!regCnt || !isFull) {
              ws.clearFusionStaging();
              break;
            }
            const fusionRes = await ws.reqFusionStagedAsync();
            ws.clearFusionStaging();
            if (fusionRes && fusionRes.length > 0) {
              loopGuard++;
              const rTid = fusionRes[0].tid || (fusionRes[0].item && fusionRes[0].item.tid);
              const rInfo = rTid && nn.db?.item?.get ? nn.db.item.get(rTid) : null;
              const rLoc = rInfo?.ItemName && nn.db?.locale?.get ? nn.db.locale.get(rInfo.ItemName) : null;
              const rName = rLoc?.VI || rLoc?.EN || rInfo?.ItemName || (rTid ? ('TID ' + rTid) : 'Jewel');
              const fuseItem = {
                sourceTier: t,
                rewardTier: t + 1,
                rewardName: rName,
                rewards: fusionRes
              };
              fusedResults.push(fuseItem);
              jewelFusedHistory.push(fuseItem);
            } else {
              break;
            }
          }
        }
        dumpEnrichedProfile();
        return JSON.stringify({ success: true, action: 'fuse', fusedCount: fusedResults.length, details: fusedResults });
      }

      if (cmd.action === 'fuseT3') {
        const ws = nn.services.workshop;
        if (!ws) return JSON.stringify({ error: 'Workshop service not found' });
        ws.setAutoRegisterIncludeStorage('Fusion', true);

        const collectT3Candidates = (targetContentType) => {
          return ws.collectAutoRegisterCandidates(
            'Fusion',
            (itemTid, itemId) => {
              const live = nn.net.data.item.getItemNotStackUniqueId(itemId);
              if (!live || live.isLock || live._isLock) return false;
              if (nn.services.itemMove?.isEquippedItemId(itemId)) return false;
              if (nn.services.steamMarket?.staging?.isStaged(itemId)) return false;
              return true;
            },
            true,
            { rating: 3 }
          ).filter(c => {
            if (c.ratingType !== 3) return false;
            const info = ws.getTableInfo(c.itemTid, c.itemId);
            return info && info.contentType === targetContentType;
          }).map(c => {
            const dbEq = nn.db.equip ? nn.db.equip.get(c.itemTid) : null;
            const info = ws.getTableInfo(c.itemTid, c.itemId);
            c._itemLevel = (info && info.baseLimitLevel > 0) ? info.baseLimitLevel : ((dbEq && dbEq.LimitLevel) || 1);
            return c;
          });
        };

        const t3Results = [];
        const isSameLv = (cmd.sameLevelOnly !== false); // Mặc định chỉ ghép cùng cấp độ nếu không chỉ định rõ

        // 1. Ghép Trang Bị T3 (Gear - cần 6 món)
        if (cmd.fuseGear !== false) {
          ws.setFusionContentType(1);
          ws.setAutoRegisterRating('Fusion', 3);
          let loop = 0;
          while (loop < 20) {
            const candidates = collectT3Candidates(1);
            if (candidates.length < 6) break;

            let selected = null;
            if (isSameLv) {
              const byLevel = new Map();
              for (let c of candidates) {
                const lv = c._itemLevel;
                if (!byLevel.has(lv)) byLevel.set(lv, []);
                byLevel.get(lv).push(c);
              }
              const sortedLevels = Array.from(byLevel.keys()).sort((a, b) => b - a);
              for (let lv of sortedLevels) {
                const grp = byLevel.get(lv);
                if (grp.length >= 6) {
                  selected = grp.slice(0, 6);
                  break;
                }
              }
              if (!selected) break;
            } else {
              selected = candidates.slice(0, 6);
            }

            const maxLv = Math.max(...selected.map(i => i._itemLevel || 1));
            const tbl = ws.findFusionTable(1, 3, maxLv);
            if (!tbl) break;
            const materials = selected.map(i => ({ itemId: i.itemId, itemTid: i.itemTid, itemCnt: 1 }));
            if (!ws.validateFusionMaterials(tbl, materials)) break;
            ws.clearFusionStaging();
            const res = await ws.reqFusionAsync(tbl.FusionID, materials);
            if (res && (res.NetResult === 0 || !res.NetResult || res.Data)) {
              loop++;
              t3Results.push({ type: 'gear', res: res });
              try { nn.msgBroker.publish('onUpdateWorkShopFusion'); } catch(_) {}
            } else {
              break;
            }
          }
        }

        // 2. Ghép Trang Sức T3 (Accessories - cần 3 món)
        if (cmd.fuseAcc !== false) {
          ws.setFusionContentType(2);
          ws.setAutoRegisterRating('Fusion', 3);
          let loop = 0;
          while (loop < 20) {
            const candidates = collectT3Candidates(2);
            if (candidates.length < 3) break;

            let selected = null;
            if (isSameLv) {
              const byLevel = new Map();
              for (let c of candidates) {
                const lv = c._itemLevel;
                if (!byLevel.has(lv)) byLevel.set(lv, []);
                byLevel.get(lv).push(c);
              }
              const sortedLevels = Array.from(byLevel.keys()).sort((a, b) => b - a);
              for (let lv of sortedLevels) {
                const grp = byLevel.get(lv);
                if (grp.length >= 3) {
                  selected = grp.slice(0, 3);
                  break;
                }
              }
              if (!selected) break;
            } else {
              selected = candidates.slice(0, 3);
            }

            const maxLv = Math.max(...selected.map(i => i._itemLevel || 1));
            const tbl = ws.findFusionTable(2, 3, maxLv);
            if (!tbl) break;
            const materials = selected.map(i => ({ itemId: i.itemId, itemTid: i.itemTid, itemCnt: 1 }));
            if (!ws.validateFusionMaterials(tbl, materials)) break;
            ws.clearFusionStaging();
            const res = await ws.reqFusionAsync(tbl.FusionID, materials);
            if (res && (res.NetResult === 0 || !res.NetResult || res.Data)) {
              loop++;
              t3Results.push({ type: 'acc', res: res });
              try { nn.msgBroker.publish('onUpdateWorkShopFusion'); } catch(_) {}
            } else {
              break;
            }
          }
        }

        dumpEnrichedProfile();
        return JSON.stringify({ success: true, action: 'fuseT3', fusedCount: t3Results.length, details: t3Results });
      }

      return JSON.stringify({ success: false, reason: 'Unknown action: ' + cmd.action });
    } catch(err) {
      return JSON.stringify({ success: false, error: err.toString(), stack: err.stack });
    }
  };

  // 1. High-speed loop (40ms) for handling interactive commands (Lò rèn, Kho ngọc, Auto Equip)
  setInterval(async () => {
    // Also process any pending commands queued via globalThis.__pendingJewelCmd
    if (globalThis.__pendingJewelCmd && !isEvaluating) {
      const pendingCmd = globalThis.__pendingJewelCmd;
      globalThis.__pendingJewelCmd = null;
      try {
        await globalThis.__runJewelAction(pendingCmd);
      } catch(_) {}
    }

    if (isEvaluating) return;
    try {
      if (typeof CS === 'undefined' || !CS.NTSHelper || !CS.UnityEngine || !CS.UnityEngine.Application) return;
      
      const dataPath = CS.UnityEngine.Application.dataPath;
      if (!dataPath) return;
      const gameDir = dataPath + '/..';
      const pendingFile = gameDir + '/pending_eval.json';
      const resultFile = gameDir + '/eval_result.json';

      if (CS.NTSHelper.IsFileExists(pendingFile)) {
        isEvaluating = true;
        let raw = '';
        try {
          raw = CS.NTSHelper.ReadAllText(pendingFile);
          CS.System.IO.File.Delete(pendingFile);
        } catch(e) {
          isEvaluating = false;
          return;
        }

        if (raw && raw.trim()) {
          try {
            const data = JSON.parse(raw);
            let evalRes = await eval(data.code);
            let valStr = (typeof evalRes === 'string') ? evalRes : JSON.stringify(evalRes);
            CS.NTSHelper.WriteAllText(resultFile, JSON.stringify({ id: data.id, result: valStr }));
          } catch(err) {
            CS.NTSHelper.WriteAllText(resultFile, JSON.stringify({ id: data ? data.id : 1, error: err.toString() }));
          }
        }
        isEvaluating = false;
      }
    } catch(e) {
      isEvaluating = false;
    }
  }, 40);

  // 2. Continuous 1-second loop for dumping live player stats INCLUDING JEWELS & WAREHOUSE
  setInterval(() => {
    const now = Date.now();
    if (now - lastDump < 1000) return;
    lastDump = now;
    dumpEnrichedProfile();
  }, 1000);
})();
`;

fs.writeFileSync(initPath, code.trim() + '\n' + hook, 'utf8');
console.log('Hook v3.2 successfully updated into init.bundle.mjs with full T3 Engine!');
